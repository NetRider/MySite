<?php /* Smarty version Smarty-3.1.18, created on 2015-10-03 11:09:44
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/correctLogout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1589967685560f9b58a2de19-95186747%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25329a874f351e261717165bce8c013beb2b9350' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/correctLogout.tpl',
      1 => 1443427642,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1589967685560f9b58a2de19-95186747',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'username' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_560f9b58a7c544_25010963',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_560f9b58a7c544_25010963')) {function content_560f9b58a7c544_25010963($_smarty_tpl) {?><p>
	Ciao <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
! La community di ElectronicsHub ti aspetta ancora qui!
</p>
<?php }} ?>
