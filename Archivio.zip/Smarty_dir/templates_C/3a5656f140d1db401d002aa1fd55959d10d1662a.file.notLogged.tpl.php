<?php /* Smarty version Smarty-3.1.18, created on 2015-10-03 11:46:04
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/notLogged.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1790522491560bd461acc8e3-91451253%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a5656f140d1db401d002aa1fd55959d10d1662a' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/notLogged.tpl',
      1 => 1443865562,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1790522491560bd461acc8e3-91451253',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_560bd461ace534_00789319',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_560bd461ace534_00789319')) {function content_560bd461ace534_00789319($_smarty_tpl) {?><ul class="nav navbar-nav navbar-right">
    <li>
        <a data-toggle="modal" data-target="#myModal">Login</a>
    </li>
    <li>
        <a href="index.php?controller=Registration&task=getRegistrationPage">Registrati</a>
    </li>
</ul>
<?php }} ?>
