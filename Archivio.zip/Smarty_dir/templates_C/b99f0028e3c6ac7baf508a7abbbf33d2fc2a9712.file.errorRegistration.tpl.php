<?php /* Smarty version Smarty-3.1.18, created on 2015-10-11 18:07:41
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/errorRegistration.tpl" */ ?>
<?php /*%%SmartyHeaderCode:862421559561a894d1dc800-30800175%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b99f0028e3c6ac7baf508a7abbbf33d2fc2a9712' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/MySite/Smarty_dir/templates/errorRegistration.tpl',
      1 => 1444579648,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '862421559561a894d1dc800-30800175',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_561a894d204cf3_27882594',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_561a894d204cf3_27882594')) {function content_561a894d204cf3_27882594($_smarty_tpl) {?><p> qualcosa e' andato storto </p>
<?php }} ?>
