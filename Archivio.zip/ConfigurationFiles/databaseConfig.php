<?php
/**
 * Created by PhpStorm.
 * User: matteopolsinelli
 * Date: 22/05/15
 * Time: 12:19
 */
global $mysqlConfig;

$mysqlConfig['username'] = 'root';
$mysqlConfig['password'] = 'pippo';
$mysqlConfig['host'] = 'localhost';
$mysqlConfig['database'] = 'ElectronicsHub';
