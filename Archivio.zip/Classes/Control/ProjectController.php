<?php
namespace Control;

include_once(dirname(__FILE__).'/../Entity/Project.php');
include_once(dirname(__FILE__).'/../Foundation/ProjectMapper.php');
include_once(dirname(__FILE__).'/../Foundation/UserMapper.php');
include_once(dirname(__FILE__).'/../Foundation/ArticleMapper.php');
include_once(dirname(__FILE__).'/../Foundation/CommentMapper.php');
include_once(dirname(__FILE__).'/../Foundation/Database.php');
include_once(dirname(__FILE__).'/../View/View.php');

use Control\Controller;
use View\View;
use Foundation\CommentMapper;
use Foundation\Database;
use Entity\Project;
use Foundation\ProjectMapper;
use Foundation\UserMapper;
use Foundation\ArticleMapper;
use Utility\Singleton;

class ProjectController extends Controller {

    public function executeTask()
    {
        switch($this->view->getTask())
        {
            case 'addNewProject':
                return $this->addNewProject();
            break;

            case 'getProjectView':
                return $this->getProjectView();
            break;

            case 'getProjectsCards':
                return $this->getProjectsCards();
            break;

            case 'deleteProject':
                return $this->deleteProject();
            break;
        }
    }

    private function getProjectsCards()
    {
        $databaseAdapter = new Database();
        $projectMapper = new ProjectMapper($databaseAdapter);
        $userMapper = new UserMapper($databaseAdapter);
        $projects = $projectMapper->getAllProjects();
        $data = array();

        if($projects)
        {
            foreach ($projects as $project)
            {
                array_push($data, array("image"=>$project->getImage(), "title"=>$project->getTitle(), "description"=>$project->getDescription(), "id"=>$project->getId()));
            }
        }

        $this->view->assignProjectsCards($data);
        $this->view->setTemplate('projectsCards');
        return $this->view->getContent();
    }

    private function getProjectView()
    {
        $databaseAdapter = new Database();
        $projectMapper = new ProjectMapper($databaseAdapter);
        $articleMapper = new ArticleMapper($databaseAdapter);
        $commentMapper = new CommentMapper($databaseAdapter);
        $userMapper = new UserMapper($databaseAdapter);

        $project = $projectMapper->getProjectById($this->view->getProjectId());
        $comments = $commentMapper->getCommentsByProjectId($project->getId());
        $projectAuthor = $userMapper->getUserById($project->getUserId());

        $dataComments = array();

        if($comments)
        {
            foreach ($comments as $comment)
            {
                $user = $userMapper->getUserByID($comment->getUserId());
                array_push($dataComments, array("author"=>$user->getUsername(), "image"=>$user->getImage(), "text"=>$comment->getText(), "authorId"=>$user->getId(), "date"=>$comment->getDate()));
            }
        }

        $dependencies = $articleMapper->getArticlesDependenciesByProjectId($project->getId());
        $this->view->assignProjectData($project->getId(), $project->getTitle(), $project->getText(), $projectAuthor->getUsername(), $project->getImage(), $project->getDate(), $dataComments, $dependencies);
        $this->view->setTemplate('projectViewer');
        return $this->view->getContent();
    }

    private function addNewProject()
    {
        $databaseAdapter = new Database();
        $projectMapper = new ProjectMapper($databaseAdapter);
        $session = Singleton::getInstance("\Control\Session");
        $project = new Project($session->getUserId(), $this->view->getProjectTitle(), $this->view->getProjectDescription(), $this->view->getProjectText(), date('o-m-d H:i:s'), "Data/projects_images/" . $this->view->getProjectImage());
        $dependencies = $this->view->getProjectDependencies();
        $this->view->responseAjaxCall($projectMapper->insertProject($project, $dependencies));
    }

    private function deleteProject()
    {
        $databaseAdapter = new Database();
        $projectMapper = new ProjectMapper($databaseAdapter);
        $file = $projectMapper->getProjectImageById($this->view->getProjectToRemove());
        if($file && $file != "Data/projects_images/default_project_image.jpg")
            unlink("/Applications/XAMPP/xamppfiles/htdocs/MySite/".$file);
        $this->view->responseAjaxCall($projectMapper->removeProjectById($this->view->getProjectToRemove()));
    }
}
